import React, { useEffect, useState } from 'react';
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList, KeyboardAvoidingView, Platform, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { io } from 'socket.io-client';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const SERVER = process.env.SERVER_URL || 'http://YOUR_SERVER_IP:4000';

function LoginScreen({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const doLogin = async () => {
    try {
      const res = await fetch(`${SERVER}/auth/login`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({username,password}) });
      if (!res.ok) return alert('Login failed');
      const data = await res.json();
      await AsyncStorage.setItem('token', data.token);
      onLogin(data);
    } catch (e) { alert('Network error'); }
  };
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>TalkoChat</Text>
      <TextInput style={styles.input} placeholder="Username" placeholderTextColor="#bbb" value={username} onChangeText={setUsername} />
      <TextInput style={styles.input} placeholder="Password" placeholderTextColor="#bbb" secureTextEntry value={password} onChangeText={setPassword} />
      <TouchableOpacity style={styles.btn} onPress={doLogin}><Text style={styles.btnText}>Login</Text></TouchableOpacity>
    </SafeAreaView>
  );
}

function ChatsScreen({ navigation, user, socket }) {
  const [chats, setChats] = useState([]);
  useEffect(() => { setChats([]); }, []);
  return (
    <SafeAreaView style={styles.container}>
      <FlatList data={chats} ListEmptyComponent={<Text style={{color:'#ccc'}}>No chats yet</Text>} renderItem={({item})=> (
        <TouchableOpacity onPress={()=>navigation.navigate('Chat',{chat:item,user,socket})} style={{padding:12}}>
          <Text style={{color:'#fff'}}>{item.name}</Text>
        </TouchableOpacity>
      )} />
    </SafeAreaView>
  );
}

function ChatScreen({ route }){
  const { chat, user, socket } = route.params;
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  useEffect(()=>{
    (async()=>{
      const token = await AsyncStorage.getItem('token');
      const res = await fetch(`${SERVER}/messages/${chat.id}`, { headers: { Authorization: `Bearer ${token}` } });
      if (res.ok){ const data = await res.json(); setMessages(data); }
    })();
    socket.emit('join_chat',{ chatId: chat.id });
    socket.on('message', (m)=>{ if (m.chatId===chat.id) setMessages(prev=>[...prev,m]); });
    return ()=>{ socket.off('message'); };
  },[]);
  const send = ()=>{ if (!text.trim()) return; socket.emit('send_message',{ chatId: chat.id, to: chat.otherId, text }); setText(''); };
  return (
    <SafeAreaView style={styles.container}>
      <FlatList data={messages} renderItem={({item}) => (
        <View style={{alignSelf: item.from===user.id? 'flex-end':'flex-start', margin:8}}>
          <View style={[styles.bubble, item.from===user.id? styles.bubbleMy:styles.bubbleOther]}>
            <Text style={{color: item.from===user.id? '#fff':'#000'}}>{item.text}</Text>
          </View>
        </View>
      )} keyExtractor={m=>String(m._id)} />
      <KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':'height'}>
        <View style={{flexDirection:'row',padding:8}}>
          <TextInput value={text} onChangeText={setText} placeholder="Message" placeholderTextColor="#bbb" style={styles.inputChat} />
          <TouchableOpacity onPress={send} style={{justifyContent:'center',padding:10}}><Text style={{color:'#fff'}}>Send</Text></TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

export default function App(){
  const Stack = createNativeStackNavigator();
  const [user, setUser] = useState(null);
  const [socket, setSocket] = useState(null);
  useEffect(()=>{(async()=>{ const token = await AsyncStorage.getItem('token'); if (token){ const s = io(SERVER, { auth: { token } }); s.on('connect', ()=>console.log('sock')); setSocket(s); const payload = JSON.parse(atob(token.split('.')[1])); setUser({ id: payload.id, username: payload.username }); } })();},[]);
  const handleLogin = (data)=>{ setUser(data.user); const s = io(SERVER, { auth: { token: data.token } }); setSocket(s); };
  return (
    <NavigationContainer>
      <Stack.Navigator>
        {!user ? (
          <Stack.Screen name="Login">
            {props=> <LoginScreen {...props} onLogin={handleLogin} />}
          </Stack.Screen>
        ) : (
          <>
            <Stack.Screen name="Chats">{props=> <ChatsScreen {...props} user={user} socket={socket}/> }</Stack.Screen>
            <Stack.Screen name="Chat" component={ChatScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,backgroundColor:'#0b0710',padding:12},
  title:{fontSize:32,color:'#cfa7ff',textAlign:'center',marginBottom:24},
  input:{borderWidth:1,borderColor:'#2b2130',padding:12,color:'#fff',borderRadius:8,marginBottom:12,backgroundColor:'#100816'},
  btn:{backgroundColor:'#6a4cff',padding:12,borderRadius:8},
  btnText:{color:'#fff',textAlign:'center'},
  bubble:{padding:10,borderRadius:8},
  bubbleMy:{backgroundColor:'#6a4cff'},
  bubbleOther:{backgroundColor:'#ddd'},
  inputChat:{flex:1,borderWidth:1,borderColor:'#2b2130',padding:10,borderRadius:20,marginRight:8,backgroundColor:'#100816',color:'#fff'}
});
