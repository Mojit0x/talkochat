const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const bodyParser = require('body-parser');

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/talkochat';

const User = require('./models/User');
const Message = require('./models/Message');
const authRouter = require('./routes/auth');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use('/auth', authRouter);

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

io.use(async (socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('Auth error'));
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    socket.userId = payload.id;
    next();
  } catch (err) {
    next(new Error('Auth error'));
  }
});

io.on('connection', (socket) => {
  console.log('connected', socket.userId);
  socket.join(socket.userId);

  socket.on('join_chat', ({ chatId }) => socket.join(chatId));

  socket.on('send_message', async (data) => {
    const msg = new Message({ chatId: data.chatId, from: socket.userId, to: data.to, text: data.text });
    await msg.save();
    io.to(data.chatId).emit('message', msg);
    io.to(data.to).emit('new_message', msg);
  });

  socket.on('typing', ({ chatId, isTyping }) => socket.to(chatId).emit('typing', { userId: socket.userId, isTyping }));
});

app.get('/messages/:chatId', async (req, res) => {
  const { chatId } = req.params;
  const msgs = await Message.find({ chatId }).sort({ createdAt: 1 }).limit(200);
  res.json(msgs);
});

mongoose.connect(MONGO_URI).then(() => {
  server.listen(process.env.PORT || 4000, () => console.log('Server up'));
}).catch(err => console.error(err));
