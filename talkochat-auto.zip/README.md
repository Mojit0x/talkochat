    # TalkoChat — Ready-to-build (Android only)

This archive contains a ready Expo + Node.js project configured to build an Android APK via EAS and GitHub Actions. Follow the three steps below; no terminal commands required on your PC.

## Quick 3-step guide (what you will do):

1. **Create an Expo account & token**
   - Visit https://expo.dev and sign up (email).
   - Go to your profile -> Access Tokens -> Create New Token. Copy it.

2. **Create a GitHub repo & upload this project**
   - Create a new repository on GitHub (name it `talkochat` or whatever you like).
   - Upload the contents of this archive (use repository web UI -> "Add file" -> "Upload files") and commit to `main` branch.

3. **Add EXPO_TOKEN secret & run Actions**
   - Go to your GitHub repo -> Settings -> Secrets and variables -> Actions -> New repository secret.
   - Name: `EXPO_TOKEN`  Value: *paste the token you copied from Expo*
   - Go to the **Actions** tab, open **Build and Upload APK (EAS)** workflow and click **Run workflow** (or push to main). Wait until it finishes.

After the workflow completes, open the workflow run and download `TalkoChat-APK` from the **Artifacts** section — that's your `.apk` file ready to install on Android.

---

## Local testing (optional)
- To run server locally you need Node.js and MongoDB. Start MongoDB, run `npm install` inside server, then `node index.js`.
- To run client locally use Expo: `npm install` in client, then `expo start` and open on your phone with Expo Go.

If you want, after you finish these steps I can:
- Walk you through the GitHub UI with screenshots, OR
- Generate a short screencast showing the 3 clicks.

Good luck — напиши коли закінчиш, і я допоможу з наступними кроками (наприклад, налаштування сервера або FCM).
